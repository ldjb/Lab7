public class Lab705Test {

	public static void main(String[] args) {
	
		Triangle tri = new Triangle(10, 11.3, 13.1);
		System.out.print("Area: ");
		System.out.println(tri.area());
		System.out.print("Perimeter: ");
		System.out.println(tri.perimeter());
	
	}

}